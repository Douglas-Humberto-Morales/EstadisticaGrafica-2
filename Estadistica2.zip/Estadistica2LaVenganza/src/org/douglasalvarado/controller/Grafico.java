package org.douglasalvarado.controller;

import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyCode;
import javax.swing.JOptionPane;
import org.douglasalvarado.bean.Datos;

/**
 *
 * @author Douglas
 */

/*Recorrer la lista
    for(Map.Entry<Integer, Integer> entry : miHashMapOrdenado.entrySet()) {
        System.out.println(entry.getKey()+" | "+entry.getValue());
    }

  Como obtener el logaritmo de base 10
    double logaritmoBase10 = Math.log(38) / Math.log(10);
*/
public class Grafico implements Initializable{
    private ArrayList<Integer> almacenDinamico =  new ArrayList<>();
    private final Map<Integer, Integer> miHashMapOrdenado = new LinkedHashMap<>();
    private final Map<Integer, Integer> intervalos = new LinkedHashMap<>();
    private ObservableList<Datos> listaDatos = FXCollections.observableArrayList();
    
    @FXML private TextField txtNumero;
    @FXML private TextField txtFrecuencia;
    @FXML private TextField txtIdato;
    @FXML private Label lblError;
    @FXML private Label lblF;
    @FXML private Label lblFr;
    @FXML private Label lblFPorcentual;
    @FXML private Label lblFG;
    @FXML private Label lblXiF; 
    @FXML private Label lblRango; 
    @FXML private Label lblK; 
    @FXML private Label lblI; 
    @FXML private Label lblFXiX;
    @FXML private Label lblFXiX2;
    @FXML private Label lblSX;
    @FXML private Label lblS;
    @FXML private Label lblS2;
    @FXML private Label lblCV;
    @FXML private Label lblX;
    @FXML private Label lblModa;
    @FXML private Label lblMediana;
    @FXML private Label lblQ1;
    @FXML private Label lblQ2;
    @FXML private Label lblQ3;
    @FXML private Label lblP10;
    @FXML private Label lblP90;
    @FXML private Label lblD3;
    @FXML private Label lblD4;
    @FXML private Label lblD5;
    @FXML private Label lblD6;
    @FXML private Label lblD7;
    @FXML private Label lblD8;
    @FXML private Label lblSesgo;
    @FXML private Label lblSesgoTipo;
    @FXML private Label lblCurtosis;
    @FXML private Label lblCurtosisTipo;
    @FXML private Button btnAgregar;
    @FXML private Button btnFinalizar;
    @FXML private Button btnFinalizar1;
    @FXML private Button btnLimpieza;
    @FXML private TableView tblDatos;
    @FXML private TableColumn colIntervalos;
    @FXML private TableColumn colLimitesReales;
    @FXML private TableColumn colF;
    @FXML private TableColumn colXi;
    @FXML private TableColumn colFa;
    @FXML private TableColumn colFr;
    @FXML private TableColumn colFPorcentual;
    @FXML private TableColumn colFG;
    @FXML private TableColumn colXiF;
    @FXML private TableColumn colXiX2;
    @FXML private TableColumn colFXiX;
    @FXML private TableColumn colFXiX2;
    @FXML private TextArea txtCopyPast;
    
    //Variables para manejar los datos 1 a 1
    //Cadenas de texto
    String tipoSesgo = "", tipoCurtosis = "";
    
    //Enteras
    private int datoMenor = 0, rango = 0, datoMayor = 0, iDato = 0, fa = 0, n = 0, 
             tempMediana = 0, vuelta = 0, valorModa = 0, faMediana = 0, dato = 0;
    
    //Con decimales (Por si puede salir)
    private double k = 0.00, Xi = 0.00 ,Fr = 0.00, FPorcentual = 0.00, 
            FG = 0.00, XIF = 0.00,  frecienciaTotalN = 0.00, frecuencia = 0.00, XiX = 0.00,
            FXiX = 0.00, XiX2 = 0.00, FXiX2 = 0.00, SX = 0.00, S2 = 0.00, S = 0.00, CV = 0.00,
            media = 0.00, moda = 0.00, dato2= 0.00, Li = 0.00, mitad = 0.00, valor = 0.00,
            sumaDatosAcumulador = 0.00, sesgo = 0.00, curtosis = 0.00;

    //Variable para manejar la suma de todos los datos
    //Enteras
    //Con decimales (Por si puede salir)
    private double FPorcentualAcumulativo = 0.00, FGAcumulativo = 0.00, XIFAcumulativo = 0.00, FrAcumulativo = 0.00, 
            X = 0.00, FXiXAcumulativo = 0.00, FXiXAcumulativo2 = 0.00;
    
    //Generamos variables booleans para poder para la ejecución
    boolean modaPaso = false,  siguiente = false;
    
    //Variables temporales
    //Q1
    double Q1Fa = 0.00, Q1Kn4 = 0.00, Q1 = 0.00;
    //Q2
    double Q2Fa = 0.00, Q2Kn4 = 0.00, Q2 = 0.00;
    //Q3
    double Q3Fa = 0.00, Q3Kn4 = 0.00, Q3 = 0.00;
    //D3
    double D3Fa = 0.00, D3Kn10 = 0.00, D3 = 0.00;
    //D4
    double D4Fa = 0.00, D4Kn10 = 0.00, D4 = 0.00;
    //D5
    double D5Fa = 0.00, D5Kn10 = 0.00, D5 = 0.00;
    //D6
    double D6Fa = 0.00, D6Kn10 = 0.00, D6 = 0.00;
    //D7
    double D7Fa = 0.00, D7Kn10 = 0.00, D7 = 0.00;
    //D8
    double D8Fa = 0.00, D8Kn10 = 0.00, D8 = 0.00;
    //P10
    double P10Fa = 0.00, P10Kn100 = 0.00, P10 = 0.00;
    //P90
    double P90Fa = 0.00, P90Kn100 = 0.00, P90 = 0.00;
    boolean Q1Continuar = true, Q2Continuar = true,Q3Continuar = true,
            D3Continuar = true, D4Continuar = true, D5Continuar = true, 
            D6Continuar = true, D7Continuar = true,D8Continuar = true, 
            P10Continuar = true, P90Continuar = true;
    
    public void resolucion(){
        //Lllamamos el metodo de ordenar
        ordenar();
        mitad =almacenDinamico.size();
        valor = Math.floor(mitad/2);
        Q1Kn4 = (1*mitad)/4;
        Q2Kn4 = (2*mitad)/4;
        Q3Kn4 = (3*mitad)/4;
        
        D3Kn10 = (3*mitad)/10;
        D4Kn10 = (4*mitad)/10;
        D5Kn10 = (5*mitad)/10;
        D6Kn10 = (6*mitad)/10;
        D7Kn10 = (7*mitad)/10;
        D8Kn10 = (8*mitad)/10;
        
        P10Kn100 = (10*mitad)/100;
        P90Kn100 = (90*mitad)/100;
        
        sumaDatosAcumulador = 0;
        for (Map.Entry<Integer, Integer> entrada : miHashMapOrdenado.entrySet()) {
            if(dato==0){ 
                //Obtenemos el primer dato
                datoMenor = entrada.getKey();
                dato = 1;
            }
            //Hacemos un for para que datoMayor obtenga el ultimo dato
            datoMayor = entrada.getKey();
        }

        //Sacamos el rando con una resta
        rango = datoMayor - datoMenor;

        //Sacamos el valor de K
        k = Math.round((1+3.3*(Math.log(frecienciaTotalN) / Math.log(10))));
        k = Math.round(k);
        
        //Validacion por si solo ingresa un dato y la resta de Rango da 0
        if (rango == 0)
            rango = 1;
        if (txtIdato.getText().isEmpty())
            iDato = (int) Math.round(rango/k);
        else
            iDato = Integer.parseInt(txtIdato.getText());
        //Sacamos el valor de i
        
        
        //Obtenemos los intervalos
        intervalos.put(datoMenor, (datoMayor+iDato)-1);
        while(datoMenor < datoMayor+1 ) {
            n++;
            intervalos.put(datoMenor, (datoMenor+iDato)-1);
            datoMenor += iDato;
        }
        
        for (Map.Entry<Integer, Integer> entry : intervalos.entrySet()) {
            //Asignamos para ser mas facil el acceso
            int key1 = entry.getKey();
            int value1 = entry.getValue();
            frecuencia = 0;
            //Obtenemos le frecuencia de cada numero
            for (Integer numero : almacenDinamico) {
                if (numero >= key1 && numero <= value1)
                    frecuencia++;
            }
            Xi = ((key1-0.5)+(value1+0.5))/2;
            XIF = Math.round((Xi*frecuencia) * 100.0) / 100.0;
            sumaDatosAcumulador += XIF;
        }
        double suma = sumaDatosAcumulador;
        double nFinal = almacenDinamico.size();
        X = suma/nFinal;
        X = Math.round(X);
        //Obtenemos todos los datos restantes
        for (Map.Entry<Integer, Integer> entry : intervalos.entrySet()) {
            //Asignamos para ser mas facil el acceso
            int key1 = entry.getKey();
            int value1 = entry.getValue();
            frecuencia = 0;
            //Obtenemos le frecuencia de cada numero
            for (Integer numero : almacenDinamico) {
                if (numero >= key1 && numero <= value1)
                    frecuencia++;
            }
            String intervalos = String.valueOf(key1 + " - " +value1);
            String limitesReales = String.valueOf((key1-0.5)+ " - " +(value1+0.5));
            
            //La frecuencia acumulativa
            fa += frecuencia;
            
            //El valor de Xi
            Xi = ((key1-0.5)+(value1+0.5))/2;
            
            //Sacamos Fr que es la frecuencia dividiva la cantidad de datos y la acumulamos
            Fr = Math.round((frecuencia/frecienciaTotalN) * 100.0) / 100.0;
            FrAcumulativo += Fr;
            
            //Sacamos el porcentaje que equivale seria frecuencia * 100 / la cantidad de datos (regla de 3) y la acumulamos
            FPorcentual = Math.round(((Fr)*100) * 100.0) / 100.0;
            FPorcentualAcumulativo += FPorcentual;
            
            //Sacamos los grados que equivale seria frecuencia * 360 / la cantidad de datos (regla de 3) y la acumulamos
            FG = Math.round(((frecuencia*360)/frecienciaTotalN) * 100.0) / 100.0;
            FGAcumulativo += FG;
            
            //Sacamos Xi*F que seria la cantidad total de numero, seria frecuencia por el dato y la acumulamos
            XIF = Math.round((Xi*frecuencia) * 100.0) / 100.0;
            XIFAcumulativo += XIF;
            
            //Sacamos Xi-X
            XiX = Xi-X;
            if (XiX<0) //Por si es negativo (Que despues de x dato si pasa) lo pasamos a positivo
                XiX = XiX * -1;
            //Ahora lo multiplicamos por F
            FXiX = frecuencia * XiX;
            FXiXAcumulativo += FXiX;
            
            //Ahora lo elevamos y multiplicamos por F para los otros datos
            XiX2 = XiX * XiX;
            FXiX2 = frecuencia * XiX2;
            FXiXAcumulativo2 += FXiX2;
            
            listaDatos.add(new Datos(intervalos,limitesReales,Xi,frecuencia,fa,Fr,FPorcentual,FG,XIF,XiX2,FXiX,FXiX2));
            vuelta += 1;
            
            //Medidas de Tendencia Central Documentar Luego
            //Q1
            if (Q1Kn4 == fa)
                Q1Continuar = true;
            
            if (Q1Continuar) {
                Q1 = (key1-0.5)+(((Q1Kn4-Q1Fa)/frecuencia)*iDato);
                Q1Continuar = false;
            }
            if (Q1Kn4>fa ) {
                Q1Continuar = true;
                Q1Fa = fa;
            }
            //Q2
            if (Q2Kn4 == fa)
                Q2Continuar = true;
            
            if (Q2Continuar) {
                Q2 = (key1-0.5)+(((Q2Kn4-Q2Fa)/frecuencia)*iDato);
                Q2Continuar = false;
            }
            if (Q2Kn4>fa ) {
                Q2Continuar = true;
                Q2Fa = fa;
            }
            //Q3
            if (Q3Kn4 == fa)
                Q3Continuar = true;
            
            if (Q3Continuar) {
                Q3 = (key1-0.5)+(((Q3Kn4-Q3Fa)/frecuencia)*iDato);
                Q3Continuar = false;
            }
            if (Q3Kn4>fa ) {
                Q3Continuar = true;
                Q3Fa = fa;
            }
            //P10
            if (P10Kn100 == fa)
                P10Continuar = true;
            
            if (P10Continuar) {
                P10 = (key1-0.5)+(((P10Kn100-P10Fa)/frecuencia)*iDato);
                P10Continuar = false;
            }
            if (P10Kn100>fa ) {
                P10Continuar = true;
                P10Fa = fa;
            }
            //P90
            if (P90Kn100 == fa)
                P90Continuar = true;
            
            if (P90Continuar) {
                P90 = (key1-0.5)+(((P90Kn100-P90Fa)/frecuencia)*iDato);
                P90Continuar = false;
            }
            if (P90Kn100>fa ) {
                P90Continuar = true;
                P90Fa = fa;
            }
            //D3
            if (D3Kn10 == fa)
                D3Continuar = true;
            
            if (D3Continuar) {
                D3 = (key1-0.5)+(((D3Kn10-D3Fa)/frecuencia)*iDato);
                D3Continuar = false;
            }
            if (D3Kn10>fa ) {
                D3Continuar = true;
                D3Fa = fa;
            }
            //D4
            if (D4Kn10 == fa)
                D4Continuar = true;
            
            if (D4Continuar) {
                D4 = (key1-0.5)+(((D4Kn10-D4Fa)/frecuencia)*iDato);
                D4Continuar = false;
            }
            if (D4Kn10>fa ) {
                D4Continuar = true;
                D4Fa = fa;
            }
            //D5
            if (D5Kn10 == fa)
                D5Continuar = true;
            
            if (D5Continuar) {
                D5 = (key1-0.5)+(((D5Kn10-D5Fa)/frecuencia)*iDato);
                D5Continuar = false;
            }
            if (D5Kn10>fa ) {
                D5Continuar = true;
                D5Fa = fa;
            }
            //D6
            if (D6Kn10 == fa)
                D6Continuar = true;
            
            if (D6Continuar) {
                D6 = (key1-0.5)+(((D6Kn10-D6Fa)/frecuencia)*iDato);
                D6Continuar = false;
            }
            if (D6Kn10>fa ) {
                D6Continuar = true;
                D6Fa = fa;
            }
            //D7
            if (D7Kn10 == fa)
                D7Continuar = true;
            
            if (D7Continuar) {
                D7 = (key1-0.5)+(((D7Kn10-D7Fa)/frecuencia)*iDato);
                D7Continuar = false;
            }
            if (D7Kn10>fa ) {
                D7Continuar = true;
                D7Fa = fa;
            }
            //D8
            if (D8Kn10 == fa)
                D8Continuar = true;
            
            if (D8Continuar) {
                D8 = (key1-0.5)+(((D8Kn10-D8Fa)/frecuencia)*iDato);
                D8Continuar = false;
            }
            if (D8Kn10>fa ) {
                D8Continuar = true;
                D8Fa = fa;
            }
            //Obtenemos la mediana
            //Comparamos si el valor es igual a fa para ver si es la mitad
            if (valor == fa)//Si es cierto entonces siguiente sera verdadero para la ejecucion de lo siguiente
                siguiente = true;
            //Si siguiente es verdadero entonces obtendremos el valor de la media
            if (siguiente){
                //La media es igual a = Li+(N/2 - fa(a) / f) * i
                media = Math.round(((key1-0.5)+(((valor-faMediana)/(frecuencia))*iDato))*100.0)/100.0;
                siguiente = false; //Siguiente pasa a false para no volverse a ejecutar
            }
            //Si siguie siendo menor el dato obtenemos fa(a) y decimos que siguiente ya puede ejecutar
            if (valor > fa){
                siguiente = true;
                faMediana = fa;
            }
            
            //Obtenemos la moda
            //Si modaPaso es verdadero ejecutara lo de adentro
            if (modaPaso) {
                //La variable dato2 obtiene la frecuencia
                dato2 = frecuencia;
                //Y dice que modaPaso ya no se vuelva a ejecutar
                modaPaso = false;
            }
            //Si la variable temporal de Mediana es menor o 
            //igual a la frecuencia actual se ejecutara
            if (tempMediana <= frecuencia) {
                //Li obtiene su dato
                Li = (key1-0.5);
                //La variable temporal de Mediana obtiene la frecuencia 
                tempMediana = (int) frecuencia;
                //El valor de moda obtiene la vuelta anterior para la frecuencia anterior
                valorModa = vuelta-1;
                //Y dice que modaPaso se ejecute nuevamente
                modaPaso = true;
            }
        }
        //Realizamos dos variables temporales
        int vuelt = 0;
        double valor3 = 0.00;
        //Repetimos la lista 
        for (Datos entidad : listaDatos) {
            //Contamos la cantidad de vueltas realizadas
            vuelt += 1;
            //Si es igual a la vuelta obtenidad con anterioridad se ejecuta
            if (vuelt == valorModa) {
                //El valor3 obtiene su frecuencia (Frecuancia anterior) 
                valor3 = entidad.getFrecuencia();
                //Rompemos el ciclo
                break;
            }
        }
        
        //Redondeamos los grados
        FGAcumulativo = Math.round((FGAcumulativo) * 100.0) / 100.0;
        
        //Medidas de Dispercion
        //Desviacion Media
        SX = Math.round((FXiXAcumulativo/n) * 100.0) / 100.0;
        
        //Varianza
        double temp = (FXiXAcumulativo2/n);
        S2 = Math.round(temp * 100.0) / 100.0;
        
        //Desviacion
        S = Math.round((Math.sqrt(temp)) * 100.0) / 100.0;
        int STemp = (int) (Math.round((Math.sqrt(temp)) * 100.0) / 100.0);
        
        //Coeficiente de variacion
        CV = Math.round(((STemp/X)*100) * 100.0) / 100.0;
        
        //Finalizamos obteniendo la Moda con todos los datos obtenidos
        moda = Math.round((Li+(((tempMediana-valor3)/
                ((tempMediana-valor3)+(tempMediana-dato2))*iDato)))*100.0)/100.0;
        
        //Redondeamos los datos de posicion
        Q1 = Math.round(Q1 * 100.0) / 100.0;
        Q2 = Math.round(Q2 * 100.0) / 100.0;
        Q3 = Math.round(Q3 * 100.0) / 100.0;
        P10 = Math.round(P10 * 100.0) / 100.0;
        P90 = Math.round(P90 * 100.0) / 100.0;
        D3 = Math.round(D3 * 100.0) / 100.0;
        D4 = Math.round(D4 * 100.0) / 100.0;
        D5 = Math.round(D5 * 100.0) / 100.0;
        D6 = Math.round(D6 * 100.0) / 100.0;
        D7 = Math.round(D7 * 100.0) / 100.0;
        D8 = Math.round(D8 * 100.0) / 100.0;
        
        //Medodas de forma
        //Sesgo
        sesgo = Math.round(((Q3-(2*Q2)+Q1)/(Q3-Q1)) * 100.0) / 100.0;
        //Curtosis
        curtosis = Math.round((0.5*((Q3-Q1)/(P90-P10))) * 1000.0) / 1000.0;
        //Verificaremos que tipo son
        //Sesgo
        if (sesgo<0)
            tipoSesgo = "Negativo";
        else if (sesgo>0) 
            tipoSesgo = "Positivo";
        else
            tipoSesgo = "Cero";
        //Curtosis
        if (curtosis<0.263)
            tipoCurtosis = "Platicúrtica";
        else if (curtosis>0.263) 
            tipoCurtosis = "Leptocúrtica";
        else
            tipoCurtosis = "Mesocúrtica";
        
        //Para finalizar seteamos los datos a la tablas y label 
        setDatos();
    }
    
    public void dato(){
        //Recolectamos los datos con 2 excepciones, si deja vacio y que solo numeros
        if (!(txtNumero.getText().matches("[0-9]*"))) {
            lblError.setText("Solo Números Por favor");
        }else if(!(txtFrecuencia.getText().matches("[0-9]*"))){
            lblError.setText("Solo Números Por favor");
        }else if(txtNumero.getText().isEmpty()){
            lblError.setText("No dejar datos vacios");
        }else if(txtFrecuencia.getText().isEmpty()){
            lblError.setText("No dejar datos vacios");            
        }else{
            int valor = Integer.parseInt(txtNumero.getText());
            int dato = Integer.parseInt(txtFrecuencia.getText());
            for (int i = 0; i < dato; i++){
                almacenDinamico.add(valor);
                sumaDatosAcumulador += valor;
            }
            txtNumero.clear();
            txtFrecuencia.clear();
            lblError.setText("Guardado");
        }
        
    }
    
    public void copiarPegar(){
        if (txtCopyPast.getText().isEmpty()) 
            JOptionPane.showMessageDialog(null, "No dejar datos vacios");
        else{
            //Obtenemos los datos por si solo quiere copiar y pegar
            String a = txtCopyPast.getText().replaceAll(" ", ",");
            
            //Separamos cada numero por una coma y por espacios en blanco
            Pattern patron = Pattern.compile("\\d+"); // Expresión regular para encontrar números
            Matcher matcher = patron.matcher(a);
            
            //Seteamos cada numero en el almacen 
            while (matcher.find()) {
                int numero = Integer.parseInt(matcher.group());
                almacenDinamico.add(numero);
                sumaDatosAcumulador += numero;
            }
            
            //Deshabilitamos el boton
            btnFinalizar1.setDisable(true);
            
            //Realizamos el procedimiento
            resolucion();
            btnLimpieza.setDisable(false);
        }
    }
    
    /*
36,30,47,60,32,35,40,50,
54,35,45,52,48,58,60,38,
32,35,56,48,30,55,49,39,
58,50,65,35,56,47,37,56,
58,50,47,58,55,39,58,45
    */
    
    public void ordenar(){
        //No entiendo que pasa investigar
        Map<Integer, Integer> mapa = new HashMap<>();
        for (int numero : almacenDinamico) {
            mapa.put(numero, mapa.getOrDefault(numero, 0) + 1);
            frecienciaTotalN ++;
        }
        
        // Convertir el HashMap a una lista de entradas y ordenarla por las claves
        List<Map.Entry<Integer, Integer>> listaOrdenada = new ArrayList<>(mapa.entrySet());
        Collections.sort(listaOrdenada, new Comparator<Map.Entry<Integer, Integer>>() {
            public int compare(Map.Entry<Integer, Integer> entrada1, Map.Entry<Integer, Integer> entrada2) {
                return entrada1.getKey().compareTo(entrada2.getKey());
            }
        });
        
        // Crear un nuevo HashMap a partir de la lista ordenada
        for (Map.Entry<Integer, Integer> entrada : listaOrdenada) {
            miHashMapOrdenado.put(entrada.getKey(), entrada.getValue());
        }
        mapa.clear();
        listaOrdenada.clear();
    }
    
    public void setDatos(){
        btnAgregar.setDisable(true);
        btnFinalizar.setDisable(true);
        btnFinalizar1.setDisable(true);
        btnLimpieza.setDisable(false);
        txtNumero.setDisable(true);
        txtFrecuencia.setDisable(true);
        txtCopyPast.setDisable(true);
        txtIdato.setDisable(true);
        
        tblDatos.setItems(listaDatos);
        colIntervalos.setCellValueFactory(new PropertyValueFactory<Datos,Integer>("valorIntervalos"));
        colLimitesReales.setCellValueFactory(new PropertyValueFactory<Datos,Integer>("valorLimitesReales"));
        colXi.setCellValueFactory(new PropertyValueFactory<Datos,Double>("Xi"));
        colF.setCellValueFactory(new PropertyValueFactory<Datos,Double>("Frecuencia"));
        colFa.setCellValueFactory(new PropertyValueFactory<Datos,String>("Fa"));
        colFr.setCellValueFactory(new PropertyValueFactory<Datos,String>("Fr"));
        colFPorcentual.setCellValueFactory(new PropertyValueFactory<Datos,String>("FPorcentual"));
        colFG.setCellValueFactory(new PropertyValueFactory<Datos,String>("FG"));
        colXiF.setCellValueFactory(new PropertyValueFactory<Datos,String>("XiF"));
        colXiX2.setCellValueFactory(new PropertyValueFactory<Datos,String>("XiX"));
        colFXiX.setCellValueFactory(new PropertyValueFactory<Datos,String>("FXiX"));
        colFXiX2.setCellValueFactory(new PropertyValueFactory<Datos,String>("FXiX2"));
        
        lblF.setText(String.valueOf(frecienciaTotalN));
        lblFr.setText(String.valueOf(FrAcumulativo));
        lblFPorcentual.setText(String.valueOf(FPorcentualAcumulativo));
        lblFG.setText(String.valueOf(FGAcumulativo));
        lblXiF.setText(String.valueOf(XIFAcumulativo));
        lblRango.setText(String.valueOf(rango));
        lblK.setText(String.valueOf(Math.round(k)));
        lblI.setText(String.valueOf(iDato));
        lblFXiX.setText(String.valueOf(FXiXAcumulativo));
        lblFXiX2.setText(String.valueOf(FXiXAcumulativo2));
        lblSX.setText(String.valueOf(SX));
        lblS2.setText(String.valueOf(S2));
        lblS.setText(String.valueOf(S));
        lblCV.setText(String.valueOf(CV));
        lblX.setText(String.valueOf(X));
        lblMediana.setText(String.valueOf(media));
        lblModa.setText(String.valueOf(moda));
        lblQ1.setText(String.valueOf(Q1));
        lblQ2.setText(String.valueOf(Q2));
        lblQ3.setText(String.valueOf(Q3));
        lblP10.setText(String.valueOf(P10));
        lblP90.setText(String.valueOf(P90));
        lblD3.setText(String.valueOf(D3));
        lblD4.setText(String.valueOf(D4));
        lblD5.setText(String.valueOf(D5));
        lblD6.setText(String.valueOf(D6));
        lblD7.setText(String.valueOf(D7));
        lblD8.setText(String.valueOf(D8));
        lblSesgo.setText(String.valueOf(sesgo));
        lblSesgoTipo.setText(tipoSesgo);
        lblCurtosis.setText(String.valueOf(curtosis));
        lblCurtosisTipo.setText(tipoCurtosis);
    }
    
    public void activarControles(){
        btnAgregar.setDisable(false);
        btnFinalizar.setDisable(false);
        btnFinalizar1.setDisable(false);
        btnLimpieza.setDisable(true);
        txtNumero.setDisable(false);
        txtFrecuencia.setDisable(false);
        txtCopyPast.setDisable(false);
        txtIdato.setDisable(false);
    }
    
    public void limpieza(){
        listaDatos.clear();
        miHashMapOrdenado.clear();
        almacenDinamico.clear();
        intervalos.clear();
        listaDatos.clear();
        txtCopyPast.clear();
        lblF.setText("F");
        lblFr.setText("Fr");
        lblFPorcentual.setText("F%");
        lblFG.setText("FG");
        lblXiF.setText("Xi*F");
        lblRango.setText("R");
        lblK.setText("K");
        lblI.setText("I");
        lblX.setText("X");
        lblModa.setText("Moda");
        lblMediana.setText("Mediana");
        lblFXiX.setText("F*|Xi-X|");
        lblFXiX2.setText("F*|Xi-X|²");
        lblSX.setText("S");
        lblS2.setText("S2");
        lblS.setText("S");
        lblCV.setText("Cv");
        lblQ1.setText("Q1");
        lblQ2.setText("Q2");
        lblQ3.setText("Q3");
        lblD3.setText("D3");
        lblD4.setText("D4");
        lblD5.setText("D5");
        lblD6.setText("D6");
        lblD7.setText("D7");
        lblD8.setText("D8");
        lblP10.setText("P10");
        lblP90.setText("P90");
        lblSesgo.setText("Sesgo");
        lblSesgoTipo.setText("Tipo");
        lblCurtosis.setText("Curtosis");
        lblCurtosisTipo.setText("Tipo");
        datoMenor = rango = datoMayor = iDato = fa = n = 
                tempMediana = vuelta = 0;
        k = Xi = Fr = FPorcentual = 0.00; 
        FG = XIF = frecienciaTotalN = frecuencia = 
            XiX = FXiX = XiX2 = FXiX2 = SX = S2 = S = CV =
                media = moda = dato2 = sumaDatosAcumulador = 0.00;
        FPorcentualAcumulativo = FGAcumulativo = 
            XIFAcumulativo = FrAcumulativo = X = FXiXAcumulativo = FXiXAcumulativo2 = 0.00;
        Q1Fa = Q1Kn4 = Q1 = Q2Fa = Q2Kn4 = Q2 = Q3Fa = Q3Kn4 = Q3 = 
            D3Fa = D3Kn10 = D3 = D4Fa = D4Kn10 = D4 = D5Fa = D5Kn10 = D5 = 
            D6Fa = D6Kn10 = D6 = D7Fa = D7Kn10 = D7 = D8Fa = D8Kn10 = D8 = 
            P10Fa = P10Kn100 = P10 = P90Fa = P90Kn100 = P90 = 0.00;
        Q1Continuar = Q2Continuar = Q3Continuar = D3Continuar = D4Continuar = D5Continuar = 
            D6Continuar = D7Continuar = D8Continuar = P10Continuar = P90Continuar = true;
        
        activarControles();
    }
    
    public void ejectarNF(){
        txtNumero.setOnKeyPressed(event -> {
            if (event.getCode() == KeyCode.ENTER)
                btnAgregar.fire();
        });
        txtFrecuencia.setOnKeyPressed(event -> {
            if (event.getCode() == KeyCode.ENTER)
                btnAgregar.fire();
        });
    }
    
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        btnLimpieza.setDisable(true);
    }
}