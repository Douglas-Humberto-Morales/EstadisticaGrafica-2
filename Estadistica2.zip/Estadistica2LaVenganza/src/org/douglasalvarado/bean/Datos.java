package org.douglasalvarado.bean;

public class Datos {
    private String valorIntervalos;
    private String valorLimitesReales;
    private double Xi;
    private double Frecuencia;
    private int Fa;
    private double Fr;
    private double FPorcentual;
    private double FG;
    private double XiF;
    private double XiX;
    private double FXiX;
    private double FXiX2;

    public Datos() {
    }

    public Datos(String valorIntervalos, String valorLimitesReales, double Xi, double Frecuencia, int Fa, double Fr, double FPorcentual, double FG, double XiF, double XiX, double FXiX, double FXiX2) {
        this.valorIntervalos = valorIntervalos;
        this.valorLimitesReales = valorLimitesReales;
        this.Xi = Xi;
        this.Frecuencia = Frecuencia;
        this.Fa = Fa;
        this.Fr = Fr;
        this.FPorcentual = FPorcentual;
        this.FG = FG;
        this.XiF = XiF;
        this.XiX = XiX;
        this.FXiX = FXiX;
        this.FXiX2 = FXiX2;
    }

    
    public String getValorIntervalos() {
        return valorIntervalos;
    }

    public void setValorIntervalos(String valorIntervalos) {
        this.valorIntervalos = valorIntervalos;
    }

    public String getValorLimitesReales() {
        return valorLimitesReales;
    }

    public void setValorLimitesReales(String valorLimitesReales) {
        this.valorLimitesReales = valorLimitesReales;
    }

    public double getXi() {
        return Xi;
    }

    public void setXi(double Xi) {
        this.Xi = Xi;
    }

    public double getFrecuencia() {
        return Frecuencia;
    }

    public void setFrecuencia(double Frecuencia) {
        this.Frecuencia = Frecuencia;
    }

    public int getFa() {
        return Fa;
    }

    public void setFa(int Fa) {
        this.Fa = Fa;
    }

    public double getFr() {
        return Fr;
    }

    public void setFr(double Fr) {
        this.Fr = Fr;
    }

    public double getFPorcentual() {
        return FPorcentual;
    }

    public void setFPorcentual(double FPorcentual) {
        this.FPorcentual = FPorcentual;
    }

    public double getFG() {
        return FG;
    }

    public void setFG(double FG) {
        this.FG = FG;
    }

    public void setFG(int FG) {
        this.FG = FG;
    }

    public double getXiF() {
        return XiF;
    }

    public void setXiF(double XiF) {
        this.XiF = XiF;
    }

    public double getXiX() {
        return XiX;
    }

    public void setXiX(double XiX) {
        this.XiX = XiX;
    }

    public double getFXiX() {
        return FXiX;
    }

    public void setFXiX(double FXiX) {
        this.FXiX = FXiX;
    }

    public double getFXiX2() {
        return FXiX2;
    }

    public void setFXiX2(double FXiX2) {
        this.FXiX2 = FXiX2;
    }
}
